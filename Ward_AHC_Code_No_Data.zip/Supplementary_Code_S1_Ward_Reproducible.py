#!/usr/bin/env python3
"""Supplementary Code S1: Ward–AHC and stress-feature sensitivity.

To run with an owner-authorized depth-matched input CSV:
  python Supplementary_Code_S1_Ward_Reproducible.py \
    --input authorized_mechanical_matrix.csv --outdir results

Required columns, with units exactly as shown:
 Depth_MD_m, SHmax_MPa, Shmin_MPa, Sv_MPa, UCS_MPa, Es_GPa
Optional post-fit labels for descriptive association: EF, MRGC

This code never uses EF to fit mechanical units or select feature weights.
The four candidate weights are an exploratory analysis chosen after EF5 inspection.
The original proprietary well-log data are not included in this supplement.
"""
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.cluster.hierarchy import linkage, fcluster
from scipy.stats import chi2_contingency
from sklearn.metrics import (adjusted_rand_score, adjusted_mutual_info_score,
                             silhouette_score, davies_bouldin_score,
                             calinski_harabasz_score)

FEATURES=['SHmax_MPa','Shmin_MPa','Sv_MPa','UCS_MPa','Es_GPa']
WEIGHTS={'AHCBASE':(1.,1.,1.,1.,1.),'AHC075':(.75,.75,.75,1.,1.),
         'AHC050':(.5,.5,.5,1.,1.),'AHC025':(.25,.25,.25,1.,1.),
         'AHCROCK':(0.,0.,0.,1.,1.)}


def ward_clusters(scaled,physical,n=5):
    if np.unique(scaled,axis=0).shape[0] < n:
        raise ValueError('Insufficient distinct observations for the requested clusters')
    raw=fcluster(linkage(scaled,method='ward',metric='euclidean'),n,criterion='maxclust')
    keys=sorted(np.unique(raw),key=lambda i:(physical[raw==i,4].mean(),physical[raw==i,3].mean()))
    names={c:i+1 for i,c in enumerate(keys)}
    return np.array([names[i] for i in raw],dtype=int)


def stats_ef(labels,ef):
    if not np.isin(ef,[1,2,3,4,5]).all():
        return {'Cramers_V':np.nan,'AMI':np.nan,'EF5_captured':np.nan,'EF5_class_purity':np.nan}
    counts=pd.crosstab(pd.Series(ef),pd.Series(labels)).reindex(index=range(1,6),columns=range(1,6),fill_value=0)
    chi2=chi2_contingency(counts.to_numpy())[0]
    v=np.sqrt(chi2/(len(ef)*4))
    ef5row=counts.loc[5].to_numpy();ix=int(np.argmax(ef5row));target=int(ef5row[ix]);size=int(counts.iloc[:,ix].sum())
    return {'Cramers_V':v,'AMI':adjusted_mutual_info_score(ef,labels),
            'EF5_captured':target,'EF5_class_purity':target/size}


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--input',required=True);ap.add_argument('--outdir',default='ward_results')
    a=ap.parse_args();out=Path(a.outdir);out.mkdir(parents=True,exist_ok=True)
    df=pd.read_csv(a.input)
    missing=[k for k in ['Depth_MD_m',*FEATURES] if k not in df]
    if missing:raise ValueError(f'Required columns missing: {missing}')
    df=df.dropna(subset=['Depth_MD_m',*FEATURES]).sort_values('Depth_MD_m').reset_index(drop=True)
    if df.Depth_MD_m.duplicated().any():raise ValueError('Depth samples must be unique')
    x=df[FEATURES].to_numpy(float)
    ranges=np.ptp(x,axis=0)
    if (ranges<=0).any():raise ValueError('Each mechanical variable needs a nonzero range')
    scaled=(x-x.min(axis=0))/ranges
    result=df[['Depth_MD_m']].copy();metrics=[]
    for name,ww in WEIGHTS.items():
        z=scaled*np.array(ww);cl=ward_clusters(z,x)
        result[name]=cl
        row={'scenario':name,'N':len(cl),'silhouette_fitted':silhouette_score(z[:,np.array(ww)!=0],cl),
             'silhouette_UCS_Es':silhouette_score(scaled[:,3:],cl),
             'Davies_Bouldin_common':davies_bouldin_score(scaled,cl),
             'Calinski_Harabasz_common':calinski_harabasz_score(scaled,cl),
             'depth_runs':int(1+np.sum(cl[1:]!=cl[:-1]))}
        for j,feat in enumerate(FEATURES):
            for k in range(1,6):
                vals=x[cl==k,j]
                row[f'{feat}_GMU{k}_mean']=float(vals.mean())
                row[f'{feat}_GMU{k}_SD']=float(vals.std(ddof=1)) if len(vals)>1 else np.nan
        if 'EF' in df.columns and df.EF.notna().all():row.update(stats_ef(cl,df.EF.to_numpy(int)))
        metrics.append(row)
    result.to_csv(out/'depth_matched_ward_labels.csv',index=False)
    pd.DataFrame(metrics).to_csv(out/'ward_sensitivity_metrics.csv',index=False)
    print('Wrote outputs for',len(df),'complete records to',out)

if __name__=='__main__':main()
